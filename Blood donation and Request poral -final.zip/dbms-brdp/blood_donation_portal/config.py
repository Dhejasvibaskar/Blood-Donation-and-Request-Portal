# config.py
import os
class Config:
    SECRET_KEY = 'your-secret-key-here-change-in-production'
# MySQL Database Configuration
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'Dheju@2006'
    MYSQL_DB = 'blooddonation'
    MYSQL_CURSORCLASS = 'DictCursor'

# db_config.py
from flask_mysqldb import MySQL
import MySQLdb.cursors

mysql = MySQL()

def init_db(app):
    # Configure MySQL connection
    app.config['MYSQL_HOST'] = 'localhost'
    app.config['MYSQL_USER'] = 'root'
    app.config['MYSQL_PASSWORD'] = 'Dheju@2006'  # Add your password if you have one
    app.config['MYSQL_DB'] = 'blooddonation'
    app.config['MYSQL_CURSORCLASS'] = 'DictCursor'  # Use string, not the type itself
    
    mysql.init_app(app)
